package com.example.dictionary.extended;

import com.example.dictionary.spi.api.Dictionary;
import java.util.SortedMap;
import java.util.TreeMap;

public class ExtendedDictionary implements Dictionary {
        private SortedMap<String, String> map;

    /**
     * Creates a new instance of ExtendedDictionary
     */
    public ExtendedDictionary() {
        map = new TreeMap<String, String>();
        map.put("XML",
                "a document standard often used in web services, among other things");
        map.put("REST",
                "an architecture style for creating, reading, updating, " +
                "and deleting data that attempts to use the common vocabulary" +
                "of the HTTP protocol; Representational State Transfer");
    }

    public String getDefinition(String word) {
        return map.get(word);
    }
}