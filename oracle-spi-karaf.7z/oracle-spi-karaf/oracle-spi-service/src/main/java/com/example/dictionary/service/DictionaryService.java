package com.example.dictionary.service;

import com.example.dictionary.spi.api.Dictionary;

import java.util.Iterator;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

public class DictionaryService {

    private static DictionaryService service;
    private ServiceLoader<Dictionary> loader;

    /**
     * Creates a new instance of DictionaryService
     */
    private DictionaryService() {
        //ClassLoader appLoader = ClassLoader.getSystemClassLoader();
        ClassLoader serviceLoader = DictionaryService.class.getClassLoader();
        ClassLoader currentLoader = Thread.currentThread().getContextClassLoader();
        //Thread.currentThread().setContextClassLoader(currentLoader);
        loader = ServiceLoader.load(Dictionary.class);
        //Thread.currentThread().setContextClassLoader(currentLoader);
    }

    /**
     * Retrieve the singleton static instance of DictionaryService.
     */
    public static synchronized DictionaryService getInstance() {
        if (service == null) {
            service = new DictionaryService();
        }
        return service;
    }

    /**
     * Retrieve definitions from the first provider
     * that contains the word.
     */
    public String getDefinition(String word) {
        String definition = null;

        try {
            Iterator<Dictionary> dictionaries = loader.iterator();
            while (definition == null && dictionaries.hasNext()) {
                Dictionary d = dictionaries.next();
                definition = d.getDefinition(word);
            }
        } catch (ServiceConfigurationError serviceError) {
            definition = null;
            serviceError.printStackTrace();

        }
        return definition;
    }
}